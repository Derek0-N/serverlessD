const { app } = require('@azure/functions');
const helloWorld = require('./functions/HelloWorld');
module.exports = app;